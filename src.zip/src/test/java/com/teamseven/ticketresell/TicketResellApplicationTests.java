package com.teamseven.ticketresell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketResellApplicationTests {

	@Test
	void contextLoads() {
	}

}
